# El Caballerito — conexión con IA

La interfaz original se conserva. El cambio principal es que el navegador ahora llama a `/api/chat` en el mismo servidor; la clave secreta de IA permanece en el backend y nunca se expone en `index.html`.

## Ejecutar localmente

1. Instala Node.js 18 o superior.
2. En esta carpeta ejecuta `npm install`.
3. Copia `.env.example` a `.env`.
4. Abre `.env` y coloca tu clave de API en `OPENAI_API_KEY`.
5. Ejecuta `npm start`.
6. Abre `http://localhost:3000`.

## Publicar en Render

1. Sube esta carpeta a un repositorio privado de GitHub.
2. En Render crea un servicio web nuevo conectado a ese repositorio.
3. Render puede detectar la configuración de `render.yaml`; usa `npm install` para compilar y `npm start` para iniciar.
4. En la sección **Environment** del servicio, agrega:
   - `OPENAI_API_KEY`: tu clave secreta de API.
   - `OPENAI_MODEL`: `gpt-4.1-mini` (opcional; ese es el valor predeterminado).
5. Despliega el servicio. La dirección pública que Render asigne será la dirección de tu aplicación.

No pegues la clave en el HTML ni la compartas públicamente. El uso de la API puede generar cargos según la cuenta y el consumo. La cuenta de API debe tener acceso y cuota disponibles.

## Comprobación

- Abre `https://TU-SERVICIO.onrender.com/health`: debe responder `{"status":"ok"}`.
- Abre la página principal y prueba, por ejemplo: `3x + 5 = 20`.
- Si falla, revisa los registros de Render y confirma que `OPENAI_API_KEY` esté configurada.
