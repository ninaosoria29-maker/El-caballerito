require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname)));

app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({
        error: "El servidor todavía no está configurado: falta OPENAI_API_KEY."
      });
    }

    const messages = req.body && req.body.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Envía un problema matemático para comenzar." });
    }

    // Only accept recent user/assistant text messages. The system prompt is
    // kept on the server and cannot be replaced by browser input.
    const safeMessages = messages.slice(-16).map(message => {
      if (!message || !["user", "assistant"].includes(message.role) ||
          typeof message.content !== "string") {
        throw new Error("El formato de la conversación no es válido.");
      }
      return {
        role: message.role,
        content: message.content.slice(0, 6000)
      };
    });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `Eres El Caballerito, un tutor de matemáticas en español.
Tu objetivo principal es resolver y enseñar con claridad problemas de álgebra de cualquier nivel, además de aritmética, geometría, trigonometría, cálculo y estadística.

Reglas para responder:
- Resuelve el ejercicio correcto y explica el procedimiento en pasos numerados.
- Muestra las operaciones y transformaciones algebraicas importantes; no saltes pasos clave.
- Explica brevemente por qué se hace cada paso, usando lenguaje sencillo y preciso.
- Comprueba el resultado sustituyéndolo en el problema original cuando sea posible.
- Si hay varias soluciones, indícalas todas y explica el conjunto solución.
- Respeta paréntesis, signos, exponentes, fracciones, unidades y condiciones del dominio.
- Si el enunciado es ambiguo o falta información, pregunta qué dato falta en vez de inventarlo.
- Si el usuario envía una expresión o ecuación sin instrucciones, interpreta que quiere resolverla o simplificarla y aclara qué hiciste.
- Si el ejercicio contiene un error, señálalo con respeto y explica cómo corregirlo.
- No inventes resultados ni afirmes haber comprobado algo que no comprobaste.
- Usa notación matemática legible en texto plano y organiza la respuesta con títulos como "Procedimiento" y "Comprobación" cuando ayude.
- Responde siempre en español, de forma amable, directa y didáctica.`
        },
        ...safeMessages
      ],
      temperature: 0.2,
      max_completion_tokens: 2500
    });

    const answer = completion.choices?.[0]?.message?.content?.trim();
    if (!answer) {
      return res.status(502).json({ error: "La IA devolvió una respuesta vacía. Inténtalo otra vez." });
    }
    res.json({ answer });
  } catch (error) {
    console.error("Error en /api/chat:", error);
    if (error.message === "El formato de la conversación no es válido.") {
      return res.status(400).json({ error: error.message });
    }
    if (error.status === 401) {
      return res.status(502).json({ error: "La clave de IA no es válida. Revisa OPENAI_API_KEY en el servidor." });
    }
    if (error.status === 429) {
      return res.status(429).json({ error: "El servicio de IA alcanzó su límite o no tiene cuota disponible. Revisa la facturación y los límites de tu API." });
    }
    res.status(500).json({ error: "Ocurrió un error al consultar la IA. Revisa los registros del servidor e inténtalo de nuevo." });
  }
});

app.listen(PORT, () => {
  console.log(`El Caballerito está activo en el puerto ${PORT}`);
});
